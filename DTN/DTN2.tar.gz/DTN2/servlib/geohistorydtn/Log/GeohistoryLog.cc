#include "GeohistoryLog.h"

namespace dtn
{
GeohistoryLog * GeohistoryLog::instance=NULL;
}
