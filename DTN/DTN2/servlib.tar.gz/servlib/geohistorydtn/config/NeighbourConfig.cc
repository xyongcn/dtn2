#include "NeighbourConfig.h"

namespace dtn
{
	std::string NeighbourConfig::NEIGHBOURAREAFILEDIR="logDocuments/geoHistory_dtn/neighbour_area/";
	std::string NeighbourConfig::NEIGHBOURAREAFILEDIR_FIRST="logDocuments/geoHistory_dtn/";
}
