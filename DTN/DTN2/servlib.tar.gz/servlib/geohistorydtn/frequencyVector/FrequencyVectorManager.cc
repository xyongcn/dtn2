#include "FrequencyVectorManager.h"

namespace dtn
{
const string FrequencyVectorManager::tag="FrequencyVectorManager";
FrequencyVectorManager *FrequencyVectorManager::Instance=NULL;
}
