#include "QuestAreaInfo.h"

namespace dtn
{
	QuestAreaInfo * QuestAreaInfo::Instance=NULL;
	const string QuestAreaInfo::tag="QuestAreaInfo";
	const string QuestAreaInfo::host="127.0.0.1";
}
