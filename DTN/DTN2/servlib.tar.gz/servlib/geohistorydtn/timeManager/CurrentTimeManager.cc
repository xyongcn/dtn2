#include "CurrentTimeManager.h"

namespace dtn
{
	CurrentTimeManager *CurrentTimeManager::instance=NULL;
}
