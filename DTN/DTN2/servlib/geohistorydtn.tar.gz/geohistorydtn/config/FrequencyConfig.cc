#include"FrequencyConfig.h"

vector<int> FrequencyConfig::frequcyType;

