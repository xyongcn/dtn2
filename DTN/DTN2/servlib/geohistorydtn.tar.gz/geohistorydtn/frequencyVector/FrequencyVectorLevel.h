/**
 *
 * 说明 :表示频率向量的级别
 */
class FrequencyVectorLevel
{
public:
	static const int minuteVector=1;
	static const int hourVector=2;
	static const int monAftEveVector=3;
	static const int weekVector=4;
	static const int monthVector=5;

};
