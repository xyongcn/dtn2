class Object_RouteMessage
{
public:
	Object_RouteMessage(){}
	virtual ~Object_RouteMessage(){}
};
